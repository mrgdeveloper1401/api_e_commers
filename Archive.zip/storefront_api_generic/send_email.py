from django.core.mail import send_mail
from storefront_api_generic.email_config import DEFAULT_FROM_EMAIL


def send_email(user, code):
    subject = 'verify email'
    message = f'equal code for verify email is {code}'
    from_email = DEFAULT_FROM_EMAIL
    recipient_list = [user.email]

    send_mail(subject, message, from_email, recipient_list)
