SPECTACULAR_SETTINGS = {
    'TITLE': 'storefront api',
    'DESCRIPTION': 'shop project',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
    # OTHER SETTINGS
}

# SPECTACULAR_SETTINGS = {
#     'SWAGGER_UI_DIST': 'SIDECAR',  # shorthand to use the sidecar instead
# 'SWAGGER_UI_FAVICON_HREF': 'SIDECAR',
# 'REDOC_DIST': 'SIDECAR',
# OTHER SETTINGS
# }
