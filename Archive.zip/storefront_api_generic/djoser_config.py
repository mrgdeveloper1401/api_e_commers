DJOSER = {
    'SERIALIZERS': {
        'user_create': 'accounts.serializers.UserCreateSerializer',
    },
}
